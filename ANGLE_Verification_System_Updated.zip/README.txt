ANGLE full scaffold
-------------------
- Frontend (Next.js) in ./frontend
- Backend (FastAPI) scaffold in ./backend
- Celery tasks and detailed Paystack code were provided in the conversation. Paste them into backend files as needed.

To run frontend locally:
  cd frontend
  npm install
  npm run dev

To run backend locally:
  cd backend
  python -m venv venv
  source venv/bin/activate
  pip install -r requirements.txt
  uvicorn main:app --reload --port 8000
