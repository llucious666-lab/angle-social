# main FastAPI app scaffold (webhook + simple endpoints)
import os
from fastapi import FastAPI
app = FastAPI()
@app.get('/')
async def root():
    return {'ok': True, 'service': 'ANGLE backend'}
